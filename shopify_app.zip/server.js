require('isomorphic-fetch');
const dotenv = require('dotenv');
const Koa = require('koa');
const next = require('next');
const { default: createShopifyAuth } = require('@shopify/koa-shopify-auth');
const { verifyRequest } = require('@shopify/koa-shopify-auth');
const session = require('koa-session');

dotenv.config();
const { default: graphQLProxy } = require('@shopify/koa-shopify-graphql-proxy');
const Router = require('koa-router');
const {receiveWebhook, registerWebhook} = require('@shopify/koa-shopify-webhooks');
const { ApiVersion } = require('@shopify/koa-shopify-graphql-proxy');

const port = parseInt(process.env.PORT, 10) || 3000;
const dev = process.env.NODE_ENV !== 'production';
const app = next({ dev });
const handle = app.getRequestHandler();

const { SHOPIFY_API_SECRET_KEY, SHOPIFY_API_KEY, HOST, } = process.env;

app.prepare().then(() => {
    const server = new Koa();
    const router = new Router();
    server.use(session(server));
    server.keys = [SHOPIFY_API_SECRET_KEY];
    server.use(
        createShopifyAuth({
          apiKey: SHOPIFY_API_KEY,
          secret: SHOPIFY_API_SECRET_KEY,
          //scopes: ['read_products'],
          scopes: ['read_products', 'write_products', 'write_script_tags'],
          async afterAuth(ctx) {
            const { shop, accessToken } = ctx.session;
            ctx.cookies.set('shopOrigin', shop, { httpOnly: false }); // Add Shopify App Bridge

            // Webhook for product creation
            const registration = await registerWebhook({
              address: `${HOST}/webhooks/products/create`,
              topic: 'PRODUCTS_CREATE',
              accessToken,
              shop,
              apiVersion: ApiVersion.October19
            });
         
            if (registration.success) {
              console.log('Successfully registered webhook!');
            } else {
              console.log('Failed to register webhook', registration.result);
            }

            // Webhook for product update
            const registration_update = await registerWebhook({
              address: `${HOST}/webhooks/products/update`,
              topic: 'PRODUCTS_UPDATE',
              accessToken,
              shop,
              apiVersion: ApiVersion.October19
            });
         
            if (registration_update.success) {
              console.log('Successfully registered webhook!');
            } else {
              console.log('Failed to register webhook', registration_update.result);
            }

            // Redirect
            ctx.redirect('/');
          },
        }),
      );
      const webhook = receiveWebhook({secret: SHOPIFY_API_SECRET_KEY});
        
      router.post('/webhooks/products/create', webhook, (ctx) => {
        console.log('received webhook: ', ctx.state.webhook);
      });
      router.post('/webhooks/products/update', webhook, (ctx) => {
        console.log('received update webhook: ');
        console.log(ctx.state);
      });

    //server.use(graphQLProxy());
    server.use(graphQLProxy({version: ApiVersion.October19}))
    // server.use(verifyRequest());
    // server.use(async (ctx) => {
    //     await handle(ctx.req, ctx.res);
    //     ctx.respond = false;
    //     ctx.res.statusCode = 200;
    //     return
    // });
    router.get('*', verifyRequest(), async (ctx) => {
      await handle(ctx.req, ctx.res);
      ctx.respond = false;
      ctx.res.statusCode = 200;
     });
     server.use(router.allowedMethods());
     server.use(router.routes());
    server.listen(port, () => {
        console.log(`> Ready on http://localhost:${port}`);
    });
});